package com.example.randomnum

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import java.util.Random


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }
    val random:Random = Random()
    var num: Int = random.nextInt(1000)

    fun validate(view:View){
        var input = findViewById<EditText>(R.id.id2)
        var dis = findViewById<TextView>(R.id.id1)
        val number = Integer.parseInt(input.text.toString())

        if(number > num){
            dis.text = "Your gusess is too high"
        }
        else if(number < num){
            dis.text = "Your guess is too low"
        }
        else
            dis.text = "BANG!"
//        383
    }



}